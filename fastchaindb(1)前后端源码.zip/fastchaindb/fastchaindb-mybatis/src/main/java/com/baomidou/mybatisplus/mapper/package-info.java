/**
 * 自动处理 CURD 基本 SQL 相关类
 */
package com.baomidou.mybatisplus.mapper;
