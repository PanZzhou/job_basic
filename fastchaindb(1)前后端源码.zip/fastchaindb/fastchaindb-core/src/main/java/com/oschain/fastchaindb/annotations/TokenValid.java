package com.oschain.fastchaindb.annotations;

import java.lang.annotation.*;

/**
 * token校验注解
 */
@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface TokenValid {
}