package com.oschain.fastchaindb.test;

public class getPath {
//        public static void main(String[] args) {
//        try{
//                String path = System.getProperty("user.dir");
//                System.out.println(path);
//        }catch (Exception e) {
//            // TODO: handle exception
//        }
//    }
}
