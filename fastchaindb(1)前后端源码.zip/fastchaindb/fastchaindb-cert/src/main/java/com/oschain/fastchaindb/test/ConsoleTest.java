package com.oschain.fastchaindb.test;

public class ConsoleTest {

}
