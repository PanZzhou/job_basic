package org.hyperledger.fabric_ca.sdk;

/**
 * Credentials supported by Fabric CA
 */
public abstract class HFCACredential {
}