/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.124.18
 Source Server Type    : MySQL
 Source Server Version : 50713
 Source Host           : 192.168.124.18:3306
 Source Schema         : fastchaindb

 Target Server Type    : MySQL
 Target Server Version : 50713
 File Encoding         : 65001

 Date: 30/12/2019 10:12:35
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for cert_block
-- ----------------------------
DROP TABLE IF EXISTS `cert_block`;
CREATE TABLE `cert_block`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block_body` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `block_hash` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `create_user` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建用户',
  `transaction_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '区块链ID',
  `block_status` int(255) NULL DEFAULT 0 COMMENT '状态0生成交易完成，1上链完成',
  `last_check_time` datetime(0) NULL DEFAULT NULL,
  `block_time` datetime(0) NULL DEFAULT NULL COMMENT '区块生成时间',
  `write_mode` int(255) NULL DEFAULT NULL COMMENT '写入模式(0同步1异步)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of cert_block
-- ----------------------------
INSERT INTO `cert_block` VALUES (1, '{\"fileId\":\"e6f9c3bb5ddd45dca4709f43b2a4407b\",\"fileHash\":\"0ee3c3fd58eef97c4b252d55c548b89cb5bb6f9f61848ffeaea0fffe580bf1db\"}', '7ec65cea88fbc63e97c3dc736803e458265c8ad60c2c19659a3b51d9efd95940', '2019-08-15 11:03:57', NULL, '422927050feb252e35b33889e549644824389ad4ac6478878d55110071356d20', 1, '2019-08-15 11:10:36', '2019-08-15 11:03:57', 1);
INSERT INTO `cert_block` VALUES (2, '{\"fileId\":\"196d95a82fc04453be99177d066b1b90\",\"fileHash\":\"c24e8c622153def027de7faaf0d8a7ab638c9de1a9aef49181ce9eed87bf6baf\"}', 'fcf14ad8a497daf2596bbec5009f3a8672f58ec44e7349b14cb9f0d259e122b9', '2019-08-15 11:08:08', NULL, '2a374d6a051953930b88542516cb231fb2b0137c4e5bd0316134d00d9e6e9396', 1, '2019-08-15 11:11:47', '2019-08-15 11:08:08', 1);
INSERT INTO `cert_block` VALUES (3, 'ddd', NULL, NULL, NULL, NULL, 0, '2019-10-15 17:47:15', NULL, NULL);
INSERT INTO `cert_block` VALUES (4, '123', '255f56f74721350abbf9b9d363b15c4392d038e1cfd0f866c7e3615b0aaeaa5e', '2019-10-17 10:41:59', NULL, 'c29ceb4f58c361619828e3600f50280be785ce94dc2feffbacd39467d6b99db7', 1, '2019-10-17 10:42:03', '2019-10-17 10:41:59', 1);
INSERT INTO `cert_block` VALUES (5, '123', '6cb65014db9f4929cc80d6685f27e874583a0c4224551dda18b83a42a0c91965', '2019-10-17 14:20:25', NULL, '483069cde6d9c4e5a16b5bbfc7baa807fbb640eb6e177b2f4b8da947ac5fbe78', 1, '2019-10-17 14:20:29', '2019-10-17 14:20:25', 1);
INSERT INTO `cert_block` VALUES (6, '123', 'e39880e5924d20fc420e8ea7f1cb58b6f62dfd8c05c716d7de29b95f74246834', '2019-10-17 15:07:51', NULL, '4f65daf0d4f7f90430df7778962727c29408469ef1ca460d479bb1e0e9e2c640', 1, '2019-10-17 15:07:53', '2019-10-17 15:07:51', 1);
INSERT INTO `cert_block` VALUES (7, '123', 'bab4d50dc415f1de847c5ed65d596e6099301177e07adb13e759d68c02a7d540', '2019-10-17 15:08:06', NULL, 'b1b3e9923619f86dea2b73fa04e741c24c9744bafdf542662e972730420b2888', 1, '2019-10-17 15:08:09', '2019-10-17 15:08:06', 1);
INSERT INTO `cert_block` VALUES (8, '123', 'ffe87f532da329f57c7d27b80257af0e4865188076d9979ea3500a57b3eb5db8', '2019-10-17 15:10:04', NULL, 'fd0b93d7bb881f2c3d839f349909416df67d086b71bb35c4da83962afb030cb8', 1, '2019-10-17 15:10:07', '2019-10-17 15:10:04', 1);
INSERT INTO `cert_block` VALUES (9, '123', 'ac4ad409d3e20313b524a4628c9cb6f0ea3e214ab555852cff2ec5fedc0e6d79', '2019-10-17 15:10:16', NULL, '07e77bef054256cc3c64d972388767d5e6782b476220eb17c426cd2f84207d4f', 1, '2019-10-17 15:10:19', '2019-10-17 15:10:16', 1);
INSERT INTO `cert_block` VALUES (10, '123', '905f04e970db2cc6039e73d1265805982add4bd78826f8547a79f1346fccdd33', '2019-10-17 15:10:19', NULL, '89943098baedbc7666f16c4f21b061c34511375b58acd525345e3643fb7cd065', 1, '2019-10-17 15:10:23', '2019-10-17 15:10:19', 1);
INSERT INTO `cert_block` VALUES (11, '123', 'b60d4a61ebaea786f2ae282a27ea93222b5c3e18de4463c5a9bb90612e7bc797', '2019-10-17 15:10:31', NULL, '6e76a7369b542dbaf4ad74da273f21d336dd5ca5151d859555b1110cfb340fad', 1, '2019-10-17 15:10:34', '2019-10-17 15:10:31', 1);
INSERT INTO `cert_block` VALUES (12, '123', '087f4a2085bf732544b4b973b7cdc15140fbb206a2cb0d58c65c034cde954122', '2019-10-17 15:11:57', NULL, 'c0306e466ac2ad5e999ce200934a53c10540819e98e2b04498978206fec47219', 1, '2019-10-17 15:12:00', '2019-10-17 15:11:57', 1);
INSERT INTO `cert_block` VALUES (13, '123', 'aeac89145d7e33ceec579da8f10e3041ac36cbaa432cab25f07645b827092067', '2019-10-17 15:12:44', NULL, '4e337d20f808c4ff576a7c77df447797341802ea40bdc588317c4bc20a1d4dfd', 1, '2019-10-17 15:12:48', '2019-10-17 15:12:44', 1);
INSERT INTO `cert_block` VALUES (14, '{\"fileId\":\"10bd55b62b5f482098b63a7054dde07b\",\"fileHash\":\"d5ab7b7d180cb329e3c53de315076c9ea8012f8000b1893d5edb8cf8b3c0f3b8\"}', 'a0957d30dcc23a58621022b195b80a5ac64c4e703e0b78ad46b709edb4b2212b', '2019-10-17 15:21:26', NULL, '3eefab9a9f4cfefc74e07af56becab0572255db78e69a7db47d06fdf51b5cf1f', 1, '2019-10-17 15:21:29', '2019-10-17 15:21:25', 1);

-- ----------------------------
-- Table structure for cert_file
-- ----------------------------
DROP TABLE IF EXISTS `cert_file`;
CREATE TABLE `cert_file`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '文件名称',
  `file_path` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '文件路径',
  `file_type` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '文件类型',
  `file_hash` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '区块链ID',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `create_user` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建用户',
  `cert_sign_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '存证标识(一对多)',
  `delete_flag` int(8) NULL DEFAULT NULL COMMENT '0生效1逻辑删除',
  `file_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '文件ID',
  `transaction_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '区块ID',
  `file_size` bigint(20) NULL DEFAULT NULL COMMENT '文件大小',
  `check_status` int(255) NULL DEFAULT NULL,
  `last_check_time` datetime(0) NULL DEFAULT NULL COMMENT '验证时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '文件表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of cert_file
-- ----------------------------
INSERT INTO `cert_file` VALUES (4, '白色透明底.png', 'uploadfile/e6f9c3bb5ddd45dca4709f43b2a4407b.png', '.png', '0ee3c3fd58eef97c4b252d55c548b89cb5bb6f9f61848ffeaea0fffe580bf1db', '2019-08-15 11:03:46', 'admin', '0a5b147f210b4f9d9d8087a83fdfac03', 0, 'e6f9c3bb5ddd45dca4709f43b2a4407b', '422927050feb252e35b33889e549644824389ad4ac6478878d55110071356d20', 4608, NULL, '2019-08-15 11:10:36');
INSERT INTO `cert_file` VALUES (5, '材料1.杭州钱塘新区高层次人才创业创新项目申请表(5)-lww.doc', 'uploadfile/196d95a82fc04453be99177d066b1b90.doc', '.doc', 'c24e8c622153def027de7faaf0d8a7ab638c9de1a9aef49181ce9eed87bf6baf', '2019-08-15 11:08:07', 'admin', 'dd307364fd0f4f8dbc76007c572d6717', 0, '196d95a82fc04453be99177d066b1b90', '2a374d6a051953930b88542516cb231fb2b0137c4e5bd0316134d00d9e6e9396', 156160, NULL, '2019-08-15 11:11:47');
INSERT INTO `cert_file` VALUES (6, 'dj产品ppt内容.docx', 'uploadfile/10bd55b62b5f482098b63a7054dde07b.docx', '.docx', 'd5ab7b7d180cb329e3c53de315076c9ea8012f8000b1893d5edb8cf8b3c0f3b8', '2019-10-17 15:21:13', 'admin', '7565703cd0ae4eaba351cb5ae873471b', 0, '10bd55b62b5f482098b63a7054dde07b', '3eefab9a9f4cfefc74e07af56becab0572255db78e69a7db47d06fdf51b5cf1f', 15075, NULL, '2019-10-17 15:21:27');

-- ----------------------------
-- Table structure for cert_info
-- ----------------------------
DROP TABLE IF EXISTS `cert_info`;
CREATE TABLE `cert_info`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_tag` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '文件标识',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `create_user` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建用户',
  `sign_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '标识ID(用于关联附件一对多)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 33 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of cert_info
-- ----------------------------
INSERT INTO `cert_info` VALUES (22, '123', '2019-08-15 11:03:48', 'admin', '0a5b147f210b4f9d9d8087a83fdfac03');
INSERT INTO `cert_info` VALUES (23, 'ad', '2019-08-15 11:08:08', 'admin', 'dd307364fd0f4f8dbc76007c572d6717');
INSERT INTO `cert_info` VALUES (32, 'aaa', '2019-10-17 15:21:19', 'admin', '7565703cd0ae4eaba351cb5ae873471b');

-- ----------------------------
-- Table structure for fabric_config
-- ----------------------------
DROP TABLE IF EXISTS `fabric_config`;
CREATE TABLE `fabric_config`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '组织名称',
  `crypto_config_path` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '证书路径',
  `org_msp_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '组织',
  `orderer_domain` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '排序域名',
  `chain_code_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '智能合约名称',
  `chain_code_path` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '智能合约路径',
  `chain_code_version` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '智能合约版本',
  `invoke_wait_time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '交易等待时间',
  `user_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名称',
  `channel_artifacts_path` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '通道配置路径',
  `org_domain` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '组织域名',
  `channel_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '通道名称',
  `chain_code_source` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '智能合约源路径',
  `chain_code_policy` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '智能合约策略',
  `proposal_wait_time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '提案等待时间',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `create_user` int(50) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `update_user` int(11) NULL DEFAULT NULL COMMENT '修改人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of fabric_config
-- ----------------------------
INSERT INTO `fabric_config` VALUES (1, 'Org1', 'crypto-config', 'Org1MSP', 'example.com', 'mycc', 'github.com/chaincode_example02', '1.0', '', 'Admin', 'channel-artifacts', 'org1.example.com', 'mychannel', 'chaincodes/sample', 'policy/chaincodeendorsementpolicy.yaml', '1', '2019-09-03 15:43:45', 2, '2019-09-03 16:28:49', 2);

-- ----------------------------
-- Table structure for fabric_monitor
-- ----------------------------
DROP TABLE IF EXISTS `fabric_monitor`;
CREATE TABLE `fabric_monitor`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '通道名称',
  `org_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '组织名称',
  `chain_code_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '智能合约名称',
  `peer_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '节点名称',
  `order_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '排序节点',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `create_user` int(50) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `update_user` int(11) NULL DEFAULT NULL COMMENT '修改人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for fabric_monitor_order
-- ----------------------------
DROP TABLE IF EXISTS `fabric_monitor_order`;
CREATE TABLE `fabric_monitor_order`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fabric_monitor_id` int(11) NULL DEFAULT NULL COMMENT '通道名称ID',
  `order_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '排序节点',
  `order_ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '节点IP',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `create_user` int(50) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `update_user` int(11) NULL DEFAULT NULL COMMENT '修改人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for fabric_monitor_peer
-- ----------------------------
DROP TABLE IF EXISTS `fabric_monitor_peer`;
CREATE TABLE `fabric_monitor_peer`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fabric_monitor_id` int(11) NULL DEFAULT NULL COMMENT '通道名称ID',
  `chain_code_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '智能合约名称',
  `peer_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '节点名称',
  `peer_ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '节点IP',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `create_user` int(50) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `update_user` int(11) NULL DEFAULT NULL COMMENT '修改人',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `fabric_monitor_peer_index`(`fabric_monitor_id`, `chain_code_name`, `peer_name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for sys_authorities
-- ----------------------------
DROP TABLE IF EXISTS `sys_authorities`;
CREATE TABLE `sys_authorities`  (
  `authority_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '权限id',
  `authority_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '权限名称',
  `authority` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '授权标识',
  `menu_url` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '菜单url',
  `parent_id` int(11) NOT NULL DEFAULT -1 COMMENT '父id',
  `is_menu` int(1) NOT NULL DEFAULT 0 COMMENT '0菜单，1按钮',
  `order_number` int(3) NOT NULL DEFAULT 0 COMMENT '排序号',
  `menu_icon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '菜单图标',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`authority_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '权限表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_authorities
-- ----------------------------
INSERT INTO `sys_authorities` VALUES (1, '系统管理', '', '', -1, 0, 2, 'layui-icon-set', '2018-06-29 11:05:41', '2018-07-13 09:13:42');
INSERT INTO `sys_authorities` VALUES (2, '用户管理', NULL, 'system/user', 1, 0, 2, NULL, '2018-06-29 11:05:41', '2018-07-13 09:13:42');
INSERT INTO `sys_authorities` VALUES (3, '查询用户', 'user:view', '', 2, 1, 3, '', '2018-07-21 13:54:16', '2018-07-21 13:54:16');
INSERT INTO `sys_authorities` VALUES (4, '添加用户', 'user:add', NULL, 2, 1, 4, NULL, '2018-06-29 11:05:41', '2018-07-13 09:13:42');
INSERT INTO `sys_authorities` VALUES (5, '修改用户', 'user:edit', NULL, 2, 1, 5, NULL, '2018-06-29 11:05:41', '2018-07-13 09:13:42');
INSERT INTO `sys_authorities` VALUES (6, '删除用户', 'user:delete', NULL, 2, 1, 6, NULL, '2018-06-29 11:05:41', '2018-07-13 09:13:42');
INSERT INTO `sys_authorities` VALUES (7, '角色管理', NULL, 'system/role', 1, 0, 7, NULL, '2018-06-29 11:05:41', '2018-07-13 09:13:42');
INSERT INTO `sys_authorities` VALUES (8, '查询角色', 'role:view', '', 7, 1, 8, '', '2018-07-21 13:54:59', '2018-07-21 13:54:58');
INSERT INTO `sys_authorities` VALUES (9, '添加角色', 'role:add', '', 7, 1, 9, '', '2018-06-29 11:05:41', '2018-07-13 09:13:42');
INSERT INTO `sys_authorities` VALUES (10, '修改角色', 'role:edit', '', 7, 1, 10, '', '2018-06-29 11:05:41', '2018-07-13 09:13:42');
INSERT INTO `sys_authorities` VALUES (11, '删除角色', 'role:delete', '', 7, 1, 11, '', '2018-06-29 11:05:41', '2018-07-13 09:13:42');
INSERT INTO `sys_authorities` VALUES (12, '角色权限管理', 'role:auth', '', 7, 1, 12, '', '2018-06-29 11:05:41', '2018-07-13 15:27:18');
INSERT INTO `sys_authorities` VALUES (13, '权限管理', NULL, 'system/authorities', 1, 0, 13, NULL, '2018-06-29 11:05:41', '2018-07-13 15:45:13');
INSERT INTO `sys_authorities` VALUES (14, '查询权限', 'authorities:view', '', 13, 1, 14, '', '2018-07-21 13:55:57', '2018-07-21 13:55:56');
INSERT INTO `sys_authorities` VALUES (15, '添加权限', 'authorities:add', '', 13, 1, 15, '', '2018-06-29 11:05:41', '2018-06-29 11:05:41');
INSERT INTO `sys_authorities` VALUES (16, '修改权限', 'authorities:edit', '', 13, 1, 16, '', '2018-07-13 09:13:42', '2018-07-13 09:13:42');
INSERT INTO `sys_authorities` VALUES (17, '删除权限', 'authorities:delete', '', 13, 1, 17, '', '2018-06-29 11:05:41', '2018-06-29 11:05:41');
INSERT INTO `sys_authorities` VALUES (18, '登录日志', NULL, 'system/loginRecord', 1, 0, 18, NULL, '2018-06-29 11:05:41', '2018-06-29 11:05:41');
INSERT INTO `sys_authorities` VALUES (19, '查询登录日志', 'loginRecord:view', '', 18, 1, 19, '', '2018-07-21 13:56:43', '2018-07-21 13:56:43');
INSERT INTO `sys_authorities` VALUES (21, '系统监控', '', '', -1, 0, 3, 'layui-icon-component', '2019-05-20 13:53:27', '2019-05-20 13:53:27');
INSERT INTO `sys_authorities` VALUES (22, 'Druid监控', '', 'iframe?url=druid', 21, 0, 1, '', '2019-05-20 13:54:55', '2019-05-20 13:54:55');
INSERT INTO `sys_authorities` VALUES (23, '存证管理', '', '', -1, 0, 1, 'layui-icon-template-1', '2019-05-23 14:43:03', '2019-05-23 14:43:03');
INSERT INTO `sys_authorities` VALUES (24, '我的存证', '', 'cert/info', 23, 0, 1, '', '2019-05-23 14:45:06', '2019-05-23 14:45:06');
INSERT INTO `sys_authorities` VALUES (25, '配置中心', '', '', -1, 0, 2, 'layui-icon-auz', '2019-07-26 15:56:45', '2019-07-26 15:56:45');
INSERT INTO `sys_authorities` VALUES (26, 'Fabric配置', '', 'fabric/fabricconfig/list', 25, 0, 0, '', '2019-07-26 15:57:22', '2019-07-26 15:57:22');
INSERT INTO `sys_authorities` VALUES (27, 'BigChainDB配置', '', '', 25, 0, 0, '', '2019-07-26 15:57:40', '2019-07-26 15:57:40');
INSERT INTO `sys_authorities` VALUES (28, 'Eth配置', '', '', 25, 0, 0, '', '2019-07-26 15:57:57', '2019-07-26 15:57:57');
INSERT INTO `sys_authorities` VALUES (29, 'fabric', '', '/fabric/fabricMonitor/list', 25, 0, 0, '', '2019-10-17 16:40:02', '2019-10-17 16:40:04');

-- ----------------------------
-- Table structure for sys_dictionary
-- ----------------------------
DROP TABLE IF EXISTS `sys_dictionary`;
CREATE TABLE `sys_dictionary`  (
  `dict_code` int(11) NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `dict_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '字典名称',
  `description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`dict_code`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '字典' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_dictionary
-- ----------------------------
INSERT INTO `sys_dictionary` VALUES (1, '性别', NULL);

-- ----------------------------
-- Table structure for sys_dictionarydata
-- ----------------------------
DROP TABLE IF EXISTS `sys_dictionarydata`;
CREATE TABLE `sys_dictionarydata`  (
  `dictdata_code` int(11) NOT NULL AUTO_INCREMENT COMMENT '字典项主键',
  `dict_code` int(11) NOT NULL COMMENT '字典主键',
  `dictdata_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '字典项值',
  `is_delete` int(1) NOT NULL DEFAULT 0 COMMENT '是否删除',
  `sort_number` int(1) NOT NULL COMMENT '排序',
  `description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`dictdata_code`) USING BTREE,
  INDEX `FK_Reference_36`(`dict_code`) USING BTREE,
  CONSTRAINT `sys_dictionarydata_ibfk_1` FOREIGN KEY (`dict_code`) REFERENCES `sys_dictionary` (`dict_code`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '字典项' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_dictionarydata
-- ----------------------------
INSERT INTO `sys_dictionarydata` VALUES (1, 1, '男', 0, 0, NULL);
INSERT INTO `sys_dictionarydata` VALUES (2, 1, '女', 0, 1, NULL);

-- ----------------------------
-- Table structure for sys_login_record
-- ----------------------------
DROP TABLE IF EXISTS `sys_login_record`;
CREATE TABLE `sys_login_record`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `os_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作系统',
  `device` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '设备名',
  `browser_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '浏览器类型',
  `ip_address` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'ip地址',
  `create_time` datetime(0) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_sys_login_record_user`(`user_id`) USING BTREE,
  CONSTRAINT `sys_login_record_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 156 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_login_record
-- ----------------------------
INSERT INTO `sys_login_record` VALUES (1, 2, 'Windows 10', 'Windows 10', 'Chrome', '169.254.80.207', '2019-05-17 17:32:51');
INSERT INTO `sys_login_record` VALUES (2, 2, 'Windows 10', 'Windows 10', 'Chrome', '169.254.80.207', '2019-05-19 16:00:32');
INSERT INTO `sys_login_record` VALUES (3, 2, 'Windows 10', 'Windows 10', 'Chrome', '169.254.80.207', '2019-05-19 16:01:51');
INSERT INTO `sys_login_record` VALUES (4, 2, 'Windows 10', 'Windows 10', 'Chrome', '169.254.80.207', '2019-05-20 09:42:10');
INSERT INTO `sys_login_record` VALUES (5, 2, 'Windows 10', 'Windows 10', 'Chrome', '169.254.80.207', '2019-05-20 09:59:53');
INSERT INTO `sys_login_record` VALUES (6, 5, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-20 13:48:49');
INSERT INTO `sys_login_record` VALUES (7, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-20 13:49:22');
INSERT INTO `sys_login_record` VALUES (8, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-20 13:56:15');
INSERT INTO `sys_login_record` VALUES (9, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-20 13:57:43');
INSERT INTO `sys_login_record` VALUES (10, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-20 14:00:17');
INSERT INTO `sys_login_record` VALUES (11, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-20 14:35:48');
INSERT INTO `sys_login_record` VALUES (12, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-20 14:53:39');
INSERT INTO `sys_login_record` VALUES (13, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-20 15:42:32');
INSERT INTO `sys_login_record` VALUES (14, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-21 16:48:58');
INSERT INTO `sys_login_record` VALUES (15, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-21 17:02:10');
INSERT INTO `sys_login_record` VALUES (16, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-21 17:41:15');
INSERT INTO `sys_login_record` VALUES (17, 7, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-21 17:43:41');
INSERT INTO `sys_login_record` VALUES (18, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-22 10:12:57');
INSERT INTO `sys_login_record` VALUES (19, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-22 14:29:31');
INSERT INTO `sys_login_record` VALUES (20, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-22 19:30:47');
INSERT INTO `sys_login_record` VALUES (21, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-23 11:32:37');
INSERT INTO `sys_login_record` VALUES (22, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-23 14:18:46');
INSERT INTO `sys_login_record` VALUES (23, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-23 14:52:51');
INSERT INTO `sys_login_record` VALUES (24, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-23 15:07:45');
INSERT INTO `sys_login_record` VALUES (25, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-23 17:26:14');
INSERT INTO `sys_login_record` VALUES (26, 2, 'Windows', 'Windows', 'Chrome', '127.0.0.1', '2019-05-23 18:44:43');
INSERT INTO `sys_login_record` VALUES (27, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-24 09:17:25');
INSERT INTO `sys_login_record` VALUES (28, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-24 16:57:55');
INSERT INTO `sys_login_record` VALUES (29, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-25 15:42:52');
INSERT INTO `sys_login_record` VALUES (30, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-25 15:43:12');
INSERT INTO `sys_login_record` VALUES (31, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-26 14:20:33');
INSERT INTO `sys_login_record` VALUES (32, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-26 15:17:21');
INSERT INTO `sys_login_record` VALUES (33, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-26 19:13:00');
INSERT INTO `sys_login_record` VALUES (34, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-27 10:13:41');
INSERT INTO `sys_login_record` VALUES (35, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-27 10:21:21');
INSERT INTO `sys_login_record` VALUES (36, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-27 13:35:01');
INSERT INTO `sys_login_record` VALUES (37, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-27 14:24:47');
INSERT INTO `sys_login_record` VALUES (38, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-05-28 10:40:04');
INSERT INTO `sys_login_record` VALUES (39, 2, 'Windows', 'Windows', 'Chrome', '127.0.0.1', '2019-05-30 18:07:19');
INSERT INTO `sys_login_record` VALUES (40, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-09 19:20:42');
INSERT INTO `sys_login_record` VALUES (41, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-09 19:32:14');
INSERT INTO `sys_login_record` VALUES (42, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-09 20:13:35');
INSERT INTO `sys_login_record` VALUES (43, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-09 20:19:12');
INSERT INTO `sys_login_record` VALUES (44, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-10 09:21:00');
INSERT INTO `sys_login_record` VALUES (45, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-17 10:58:09');
INSERT INTO `sys_login_record` VALUES (46, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-17 11:01:59');
INSERT INTO `sys_login_record` VALUES (47, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-17 11:08:59');
INSERT INTO `sys_login_record` VALUES (48, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-17 14:51:57');
INSERT INTO `sys_login_record` VALUES (49, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-17 16:33:06');
INSERT INTO `sys_login_record` VALUES (50, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-18 09:22:59');
INSERT INTO `sys_login_record` VALUES (51, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-18 09:39:54');
INSERT INTO `sys_login_record` VALUES (52, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-18 10:34:46');
INSERT INTO `sys_login_record` VALUES (53, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-18 10:43:43');
INSERT INTO `sys_login_record` VALUES (54, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-18 10:44:26');
INSERT INTO `sys_login_record` VALUES (55, 11, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-18 10:44:58');
INSERT INTO `sys_login_record` VALUES (56, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-18 10:45:16');
INSERT INTO `sys_login_record` VALUES (57, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-18 11:09:11');
INSERT INTO `sys_login_record` VALUES (58, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-18 13:33:15');
INSERT INTO `sys_login_record` VALUES (59, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-18 16:06:18');
INSERT INTO `sys_login_record` VALUES (60, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-18 17:15:47');
INSERT INTO `sys_login_record` VALUES (61, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-19 17:02:19');
INSERT INTO `sys_login_record` VALUES (62, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-19 18:09:27');
INSERT INTO `sys_login_record` VALUES (63, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-20 10:55:12');
INSERT INTO `sys_login_record` VALUES (64, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-20 10:55:17');
INSERT INTO `sys_login_record` VALUES (65, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-20 13:53:42');
INSERT INTO `sys_login_record` VALUES (66, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-20 15:16:19');
INSERT INTO `sys_login_record` VALUES (67, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-20 16:56:10');
INSERT INTO `sys_login_record` VALUES (68, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-21 10:06:02');
INSERT INTO `sys_login_record` VALUES (69, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-21 10:19:49');
INSERT INTO `sys_login_record` VALUES (70, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-21 13:44:58');
INSERT INTO `sys_login_record` VALUES (71, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-24 10:36:18');
INSERT INTO `sys_login_record` VALUES (72, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-24 11:02:44');
INSERT INTO `sys_login_record` VALUES (73, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-24 11:11:15');
INSERT INTO `sys_login_record` VALUES (74, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-24 11:16:36');
INSERT INTO `sys_login_record` VALUES (75, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-24 11:34:45');
INSERT INTO `sys_login_record` VALUES (76, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-24 11:39:00');
INSERT INTO `sys_login_record` VALUES (77, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-24 11:47:02');
INSERT INTO `sys_login_record` VALUES (78, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-24 13:43:54');
INSERT INTO `sys_login_record` VALUES (79, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-24 14:22:13');
INSERT INTO `sys_login_record` VALUES (80, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-24 15:57:41');
INSERT INTO `sys_login_record` VALUES (81, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-24 17:19:41');
INSERT INTO `sys_login_record` VALUES (82, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-25 11:32:54');
INSERT INTO `sys_login_record` VALUES (83, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-25 11:33:55');
INSERT INTO `sys_login_record` VALUES (84, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-25 13:57:01');
INSERT INTO `sys_login_record` VALUES (85, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-25 14:45:19');
INSERT INTO `sys_login_record` VALUES (86, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-25 15:59:13');
INSERT INTO `sys_login_record` VALUES (87, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-25 16:12:58');
INSERT INTO `sys_login_record` VALUES (88, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-26 09:52:40');
INSERT INTO `sys_login_record` VALUES (89, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-26 17:59:44');
INSERT INTO `sys_login_record` VALUES (90, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-26 18:10:42');
INSERT INTO `sys_login_record` VALUES (91, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-26 18:42:08');
INSERT INTO `sys_login_record` VALUES (92, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-27 09:46:07');
INSERT INTO `sys_login_record` VALUES (93, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-27 10:09:31');
INSERT INTO `sys_login_record` VALUES (94, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-27 10:17:13');
INSERT INTO `sys_login_record` VALUES (95, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-27 13:35:22');
INSERT INTO `sys_login_record` VALUES (96, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-27 14:10:00');
INSERT INTO `sys_login_record` VALUES (97, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-27 16:46:43');
INSERT INTO `sys_login_record` VALUES (98, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-06-28 14:00:36');
INSERT INTO `sys_login_record` VALUES (99, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-01 09:37:53');
INSERT INTO `sys_login_record` VALUES (100, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-01 17:20:19');
INSERT INTO `sys_login_record` VALUES (101, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-01 17:51:43');
INSERT INTO `sys_login_record` VALUES (102, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-01 18:43:59');
INSERT INTO `sys_login_record` VALUES (103, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-02 15:10:18');
INSERT INTO `sys_login_record` VALUES (104, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-03 16:14:23');
INSERT INTO `sys_login_record` VALUES (105, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-03 16:18:32');
INSERT INTO `sys_login_record` VALUES (106, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-03 17:14:34');
INSERT INTO `sys_login_record` VALUES (107, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-03 18:01:29');
INSERT INTO `sys_login_record` VALUES (108, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-08 16:13:18');
INSERT INTO `sys_login_record` VALUES (109, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 17:43:45');
INSERT INTO `sys_login_record` VALUES (110, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 18:04:21');
INSERT INTO `sys_login_record` VALUES (111, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 18:08:13');
INSERT INTO `sys_login_record` VALUES (112, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 20:03:46');
INSERT INTO `sys_login_record` VALUES (113, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 20:04:25');
INSERT INTO `sys_login_record` VALUES (114, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 20:13:24');
INSERT INTO `sys_login_record` VALUES (115, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 20:17:09');
INSERT INTO `sys_login_record` VALUES (116, 3, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 20:23:32');
INSERT INTO `sys_login_record` VALUES (117, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 20:33:02');
INSERT INTO `sys_login_record` VALUES (118, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 20:36:43');
INSERT INTO `sys_login_record` VALUES (119, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 22:09:49');
INSERT INTO `sys_login_record` VALUES (120, 3, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 22:13:58');
INSERT INTO `sys_login_record` VALUES (121, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 22:14:37');
INSERT INTO `sys_login_record` VALUES (122, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-09 22:23:36');
INSERT INTO `sys_login_record` VALUES (123, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-10 08:58:33');
INSERT INTO `sys_login_record` VALUES (124, 3, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-10 09:17:43');
INSERT INTO `sys_login_record` VALUES (125, 2, 'Windows', 'Windows', 'Chrome', '127.0.0.1', '2019-07-10 09:20:32');
INSERT INTO `sys_login_record` VALUES (126, 2, 'Windows', 'Windows', 'Chrome', '127.0.0.1', '2019-07-10 09:21:02');
INSERT INTO `sys_login_record` VALUES (127, 2, 'Windows', 'Windows', 'Chrome', '127.0.0.1', '2019-07-10 09:22:56');
INSERT INTO `sys_login_record` VALUES (128, 2, 'Windows', 'Windows', 'Chrome', '127.0.0.1', '2019-07-10 09:47:12');
INSERT INTO `sys_login_record` VALUES (129, 2, 'Windows 10', 'Windows 10', 'Chrome', '169.254.80.207', '2019-07-10 14:01:10');
INSERT INTO `sys_login_record` VALUES (130, 2, 'Windows 10', 'Windows 10', 'Chrome', '169.254.80.207', '2019-07-10 14:06:36');
INSERT INTO `sys_login_record` VALUES (131, 2, 'Windows 10', 'Windows 10', 'Chrome', '169.254.80.207', '2019-07-10 14:14:18');
INSERT INTO `sys_login_record` VALUES (132, 3, 'Windows 10', 'Windows 10', 'Chrome', '169.254.80.207', '2019-07-10 14:14:29');
INSERT INTO `sys_login_record` VALUES (133, 2, 'Windows 10', 'Windows 10', 'Chrome', '169.254.80.207', '2019-07-10 14:38:24');
INSERT INTO `sys_login_record` VALUES (134, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-26 15:55:50');
INSERT INTO `sys_login_record` VALUES (135, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-26 15:58:21');
INSERT INTO `sys_login_record` VALUES (136, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-26 15:59:58');
INSERT INTO `sys_login_record` VALUES (137, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-26 16:00:20');
INSERT INTO `sys_login_record` VALUES (138, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-07-31 14:13:50');
INSERT INTO `sys_login_record` VALUES (139, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-08-15 10:44:52');
INSERT INTO `sys_login_record` VALUES (140, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-08-15 11:03:37');
INSERT INTO `sys_login_record` VALUES (141, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-08-15 13:42:42');
INSERT INTO `sys_login_record` VALUES (142, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-09-03 15:34:37');
INSERT INTO `sys_login_record` VALUES (143, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-09-03 15:35:44');
INSERT INTO `sys_login_record` VALUES (144, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-09-03 15:36:55');
INSERT INTO `sys_login_record` VALUES (145, 2, 'Windows', 'Windows', 'Chrome', '169.254.80.207', '2019-09-03 17:13:12');
INSERT INTO `sys_login_record` VALUES (146, 2, 'Windows', 'Windows', 'Chrome', '192.168.14.1', '2019-10-17 15:03:00');
INSERT INTO `sys_login_record` VALUES (147, 2, 'Windows', 'Windows', 'Chrome', '192.168.14.1', '2019-10-17 16:36:32');
INSERT INTO `sys_login_record` VALUES (148, 2, 'Windows', 'Windows', 'Chrome', '192.168.14.1', '2019-10-17 16:40:27');
INSERT INTO `sys_login_record` VALUES (149, 2, 'Windows', 'Windows', 'Chrome', '192.168.14.1', '2019-10-17 19:48:18');
INSERT INTO `sys_login_record` VALUES (150, 2, 'Windows', 'Windows', 'Chrome', '192.168.14.1', '2019-10-21 11:35:09');
INSERT INTO `sys_login_record` VALUES (151, 2, 'Windows', 'Windows', 'Chrome', '192.168.14.1', '2019-10-28 10:19:50');
INSERT INTO `sys_login_record` VALUES (152, 2, 'Windows', 'Windows', 'Chrome', '192.168.14.1', '2019-10-28 14:01:16');
INSERT INTO `sys_login_record` VALUES (153, 2, 'Windows', 'Windows', 'Chrome', '192.168.14.1', '2019-10-28 16:30:22');
INSERT INTO `sys_login_record` VALUES (154, 2, 'Windows', 'Windows', 'Chrome', '192.168.14.1', '2019-10-29 17:39:24');
INSERT INTO `sys_login_record` VALUES (155, 2, 'Windows', 'Windows', 'Chrome', '192.168.14.1', '2019-11-04 09:25:45');

-- ----------------------------
-- Table structure for sys_person
-- ----------------------------
DROP TABLE IF EXISTS `sys_person`;
CREATE TABLE `sys_person`  (
  `person_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '人员id',
  `true_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '真实姓名',
  `department_id` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '部门id',
  `position_id` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '职位id',
  `birthday` date NULL DEFAULT NULL COMMENT '出生日期',
  `id_card` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '身份证号',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`person_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '人员表' ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `role_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `role_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色名称',
  `comments` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `is_delete` int(1) NOT NULL DEFAULT 0 COMMENT '是否删除，0否，1是',
  `create_time` datetime(0) NOT NULL COMMENT '创建时间',
  `update_time` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, '超级管理员', '超级管理员', 0, '2018-07-21 09:58:31', '2018-07-21 11:07:16');
INSERT INTO `sys_role` VALUES (2, '管理员', '系统管理员', 0, '2018-07-21 09:58:35', '2018-07-21 11:07:18');
INSERT INTO `sys_role` VALUES (3, '普通用户', '系统普通用户', 0, '2018-07-21 09:58:39', '2018-07-21 11:07:23');
INSERT INTO `sys_role` VALUES (4, '1', '1', 1, '2019-05-26 19:24:52', '2019-05-26 19:24:55');
INSERT INTO `sys_role` VALUES (5, '1', '13', 1, '2019-05-26 19:25:46', '2019-05-26 19:29:13');
INSERT INTO `sys_role` VALUES (6, '1', '1', 0, '2019-05-30 18:08:28', '2019-05-30 18:08:28');

-- ----------------------------
-- Table structure for sys_role_authorities
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_authorities`;
CREATE TABLE `sys_role_authorities`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL COMMENT '角色id',
  `authority_id` int(11) NOT NULL COMMENT '权限id',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_sys_role_permission_pm`(`authority_id`) USING BTREE,
  INDEX `FK_sys_role_permission_role`(`role_id`) USING BTREE,
  CONSTRAINT `sys_role_authorities_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`role_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sys_role_authorities_ibfk_3` FOREIGN KEY (`authority_id`) REFERENCES `sys_authorities` (`authority_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 187 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色权限关联表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_role_authorities
-- ----------------------------
INSERT INTO `sys_role_authorities` VALUES (62, 1, 21, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (63, 1, 22, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (64, 1, 1, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (65, 1, 2, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (66, 1, 3, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (67, 1, 4, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (68, 1, 5, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (69, 1, 6, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (70, 1, 7, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (71, 1, 8, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (72, 1, 9, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (73, 1, 10, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (74, 1, 11, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (75, 1, 12, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (76, 1, 13, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (77, 1, 14, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (78, 1, 15, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (79, 1, 16, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (80, 1, 17, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (81, 1, 18, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (82, 1, 19, '2019-05-20 13:56:09');
INSERT INTO `sys_role_authorities` VALUES (127, 3, 23, '2019-06-18 10:45:35');
INSERT INTO `sys_role_authorities` VALUES (128, 3, 24, '2019-06-18 10:45:35');
INSERT INTO `sys_role_authorities` VALUES (129, 3, 1, '2019-06-18 10:45:35');
INSERT INTO `sys_role_authorities` VALUES (130, 3, 18, '2019-06-18 10:45:35');
INSERT INTO `sys_role_authorities` VALUES (131, 3, 19, '2019-06-18 10:45:35');
INSERT INTO `sys_role_authorities` VALUES (159, 2, 23, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (160, 2, 24, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (161, 2, 1, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (162, 2, 2, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (163, 2, 3, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (164, 2, 4, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (165, 2, 5, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (166, 2, 6, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (167, 2, 7, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (168, 2, 8, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (169, 2, 9, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (170, 2, 10, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (171, 2, 11, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (172, 2, 12, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (173, 2, 13, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (174, 2, 14, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (175, 2, 15, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (176, 2, 16, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (177, 2, 17, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (178, 2, 18, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (179, 2, 19, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (180, 2, 25, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (181, 2, 26, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (182, 2, 27, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (183, 2, 28, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (184, 2, 29, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (185, 2, 21, '2019-10-17 16:40:25');
INSERT INTO `sys_role_authorities` VALUES (186, 2, 22, '2019-10-17 16:40:25');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '账号',
  `password` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '密码',
  `nick_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '昵称',
  `avatar` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '头像',
  `sex` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '男' COMMENT '性别',
  `phone` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `email_verified` int(11) NULL DEFAULT NULL COMMENT '邮箱是否验证，0未验证，1已验证',
  `person_id` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '人员id,关联person表',
  `person_type` int(11) NULL DEFAULT NULL COMMENT '人员类型,比如:0学生,1教师',
  `state` int(1) NOT NULL DEFAULT 0 COMMENT '状态，0正常，1冻结',
  `create_time` datetime(0) NOT NULL COMMENT '注册时间',
  `update_time` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  `access_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '注册ID',
  `access_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '注册KEY',
  `idcard` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '身份证号',
  PRIMARY KEY (`user_id`) USING BTREE,
  UNIQUE INDEX `user_account`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 'superadmin', 'bd6b5b654b42b8e3aa59f7be5c739cd1', '超级管理员', NULL, '男', '12345678901', NULL, NULL, NULL, 1, 0, '2018-07-21 10:03:40', '2019-07-10 14:10:14', NULL, NULL, NULL);
INSERT INTO `sys_user` VALUES (2, 'admin', '3fed7a346e430ea4c2aa10250928f4de', '管理员', NULL, '男', '12345678901', NULL, NULL, NULL, 1, 0, '2018-07-21 10:50:18', '2019-07-10 14:10:16', NULL, NULL, '11082419621125333X');
INSERT INTO `sys_user` VALUES (3, 'demo', '180aca749787e2993b13e186d65a32f0', '测试账号', NULL, '女', '12345678901', NULL, NULL, NULL, 2, 0, '2018-07-21 10:50:27', '2019-07-10 14:10:32', NULL, NULL, NULL);
INSERT INTO `sys_user` VALUES (4, 'demo1', '7d8b316047b198a0a3e1513ee75c86d6', 'admin', NULL, '男', '12345678901', NULL, NULL, NULL, 1, 0, '2018-07-21 10:56:07', '2019-07-10 14:10:35', NULL, NULL, NULL);
INSERT INTO `sys_user` VALUES (5, 'test', '9afcd3271d7449cdbb61923c8e89ea91', 'test', NULL, '男', '13588089184', NULL, NULL, NULL, 1, 0, '2019-05-20 13:48:18', '2019-07-10 14:10:36', NULL, NULL, '33082419821125333X');
INSERT INTO `sys_user` VALUES (6, '13588082343', 'fe5a7fac20e68e6eae89dfaff3e139bd', '1', NULL, '男', '13588082343', NULL, NULL, NULL, 1, 0, '2019-05-21 17:25:23', '2019-07-10 14:10:36', NULL, NULL, NULL);
INSERT INTO `sys_user` VALUES (7, '13588089184', '0c7d65190ca1d603f594ea2bc2a07652', '1', NULL, '男', '13588089184', NULL, NULL, NULL, 1, 0, '2019-05-21 17:28:48', '2019-07-10 14:10:37', NULL, NULL, NULL);
INSERT INTO `sys_user` VALUES (8, 'a', '38aedd26e7e117ec8e82fde2201ca6fa', 'a1', NULL, '女', '13588089183', NULL, NULL, NULL, 1, 0, '2019-05-22 10:13:55', '2019-07-10 14:10:38', '0b79087b119c42c88dbab3bebf4eccc9', 'DhWunV2xatHCA2UQsd8BESoPQqAjuf819tL69KFccXThfQqLmEPhMEd', NULL);
INSERT INTO `sys_user` VALUES (9, '13588089416', 'd5c79899f8059404f61ae76bc1022699', 'kevin', NULL, '男', '13588089416', NULL, NULL, NULL, 1, 0, '2019-05-27 14:24:27', '2019-07-10 14:10:39', '12478fb074964134900a12d2d3411cef', 'AmWSepGBWzWLtpkWnBD7LcXiNbrKGBqqcHq6C47UfuN9oNAdtxwzbzD', NULL);
INSERT INTO `sys_user` VALUES (10, '13523234444', 'be2b202d6a2f0954199b0e6bd4a1520f', '123', NULL, '男', '13523234444', NULL, NULL, NULL, 1, 0, '2019-06-18 10:34:29', '2019-07-10 14:10:40', '92f5a13b2b8d455e836829e6b872f215', '9RQrtATrB4JAzExji13DCpa13UuG9qP74hdusYv6LQS83SGhwHS1peR', '11082419621125333X');
INSERT INTO `sys_user` VALUES (11, '13588089182', '30df1062fa5f246e90673686acde42f3', '12', NULL, '男', '13588089182', NULL, NULL, NULL, 1, 0, '2019-06-18 10:43:42', '2019-07-10 14:10:43', 'edffd447d39a4997994d926abac2cad2', '433RmX8svpaVwx8GtUpeCeMabgTnz2N89DZ7d3zZ2jgn336j4iM6XGZ', '53082419561125333x');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `role_id` int(11) NOT NULL COMMENT '角色id',
  `create_time` datetime(0) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_sys_user_role`(`user_id`) USING BTREE,
  INDEX `FK_sys_user_role_role`(`role_id`) USING BTREE,
  CONSTRAINT `sys_user_role_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `sys_user_role_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`role_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户角色关联表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES (1, 1, 1, '2018-07-18 15:25:50');
INSERT INTO `sys_user_role` VALUES (3, 3, 3, '2018-07-20 11:52:45');
INSERT INTO `sys_user_role` VALUES (5, 4, 3, '2018-07-21 10:56:15');
INSERT INTO `sys_user_role` VALUES (10, 2, 2, '2019-05-02 16:52:59');
INSERT INTO `sys_user_role` VALUES (12, 6, 3, '2019-05-21 17:25:23');
INSERT INTO `sys_user_role` VALUES (13, 7, 3, '2019-05-21 17:28:49');
INSERT INTO `sys_user_role` VALUES (16, 8, 3, '2019-05-22 14:29:54');
INSERT INTO `sys_user_role` VALUES (17, 9, 3, '2019-05-27 14:24:27');
INSERT INTO `sys_user_role` VALUES (20, 10, 3, '2019-06-18 10:42:51');
INSERT INTO `sys_user_role` VALUES (22, 11, 3, '2019-06-18 10:44:00');
INSERT INTO `sys_user_role` VALUES (23, 5, 3, '2019-07-09 20:07:38');

-- ----------------------------
-- View structure for v_fabric_monitor
-- ----------------------------
DROP VIEW IF EXISTS `v_fabric_monitor`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `v_fabric_monitor` AS select `a`.`id` AS `id`,`a`.`channel_name` AS `channel_name`,`a`.`org_name` AS `org_name`,`b`.`order_name` AS `order_name`,`b`.`order_ip` AS `order_ip`,`c`.`chain_code_name` AS `chain_code_name`,`c`.`peer_name` AS `peer_name`,`c`.`peer_ip` AS `peer_ip` from ((`fabric_monitor` `a` left join `fabric_monitor_order` `b` on((`a`.`id` = `b`.`fabric_monitor_id`))) left join `fabric_monitor_peer` `c` on((`a`.`id` = `c`.`fabric_monitor_id`)));

-- ----------------------------
-- Procedure structure for my_insert
-- ----------------------------
DROP PROCEDURE IF EXISTS `my_insert`;
delimiter ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `my_insert`()
BEGIN
   DECLARE n int DEFAULT 1;
        loopname:LOOP
            INSERT INTO sys_login_record(user_id,os_name,create_time)VALUES(2,'lilis',NOW());
            SET n=n+1;
        IF n=1000 THEN
            LEAVE loopname;
        END IF;
        END LOOP loopname;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for p_delete
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_delete`;
delimiter ;;
CREATE DEFINER=`root`@`%` PROCEDURE `p_delete`(in i_id VARCHAR(50),
  in i_tablename VARCHAR(50),
  in i_ip VARCHAR(50),
  in i_userid VARCHAR(50),
  in i_des VARCHAR(500),
  out o_msg VARCHAR(200))
begin

#declare var1 varchar(20) default '1';
#declare var2 varchar(20);
--  多个列的情况下似乎只能用 into 方式  
#select max(status), avg(status) into @max, @avg from test_tbl;  
#select @max, @avg;  
#set error=3 即删除内容存在子集，特殊处理

declare my_sql varchar(500); 

DECLARE t_error INTEGER DEFAULT 0;
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
START TRANSACTION;

#delete from test where id=i_id;
#DECLARE cnt int DEFAULT 0;

#删除sys_station
if (i_tablename = 'sys_station1') THEN

  select count(*) into @cnt from sys_process_flow where station_id=i_id;
  if (@cnt=0) then
		delete from sys_station where id=i_id;
  else 
		set t_error=3;
  end if;

#删除sys_plc
elseif (i_tablename = 'sys_plc') THEN

	delete from sys_plc where id=i_id;
	delete from sys_unit_plc where plc_id=i_id;

#删除sys_device
elseif (i_tablename = 'sys_device') THEN

	delete from sys_device where id=i_id;
	delete from sys_unit_device where device_id=i_id;

#删除lab_quota_data
elseif (i_tablename = 'lab_quota_data') THEN

	delete from lab_quota_data where batch_id=i_id;

#删除lab_task
elseif (i_tablename = 'lab_task') THEN
  select count(*) into @cnt from lab_sample where task_id=i_id;
  if (@cnt=0) then
		delete from lab_task where id=i_id;
		delete from lab_process_step where task_id=i_id;
  else 
		set t_error=3;
  end if;

#删除(通用)
else

 set my_sql=concat('delete from ',i_tablename,' where id=''',i_id,''''); #拼接SQL语句
 set @ms=my_sql; #注意很重要，将连成成的字符串赋值给一个变量（可以之前没有定义，但要以@开头）
 PREPARE s1 from @ms; #预处理需要执行的动态SQL，其中s1是一个变量
 EXECUTE s1; #执行SQL语句
 deallocate prepare s1; #释放掉预处理段

end if;



#set var1='1';
#set var2='b';
#insert into test(id,name)values(var1,var2);


IF t_error = 1 THEN
    ROLLBACK;
ELSE
    COMMIT;
END IF;

set o_msg=t_error;
 
end
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
